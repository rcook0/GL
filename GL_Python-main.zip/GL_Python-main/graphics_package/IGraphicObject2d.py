"""Auto-translated skeleton from WINDOWS/Desktop/GraphicsPackage/IGraphicObject2d.java.
This file preserves classes, methods, and fields.
Bodies marked TODO.
"""
from __future__ import annotations
from typing import Any, Optional, List, Dict, Tuple, Iterable
import math

class IGraphicObject2d:
    def __init__(self):
        pass
    pass
