package AnalogClock;

/**
 * A Class class.
 * <P>
 * @author 
 */
public class ViewAppMenu1 extends JMenuBar {

  /**
   * Constructor
   */
  public ViewAppMenu1() {
  }

  /**
   * main
   * @param args
   */
  public static void main(String[] args) {
    ViewAppMenu1 viewAppMenu1 = new ViewAppMenu1();
  }
}

 