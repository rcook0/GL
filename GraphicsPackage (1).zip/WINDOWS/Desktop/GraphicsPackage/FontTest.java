import java.awt.*;

/**
 * A Class class.
 * <P>
 * @author 
 */
public class FontTest extends Object {

  /**
   * main
   * @param args
   */
  public static void main(String[] args) {
    Font myFont = new Font("Arial Bold", 1, 12);
    //myFont.
  }
} 